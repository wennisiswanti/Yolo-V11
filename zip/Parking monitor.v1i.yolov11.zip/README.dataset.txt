# Parking monitor > 2023-05-11 6:23pm
https://universe.roboflow.com/university-of-patras-1jcsr/parking-monitor

Provided by a Roboflow user
License: CC BY 4.0

